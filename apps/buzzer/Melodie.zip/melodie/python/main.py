from arduino.app_utils import Bridge
from arduino.app_bricks.streamlit_ui import st

st.title("Seleziona la canzone che vuoi!")
st.write("Clicca un pulsante per far partire la canzone")

# Piccolo helper per mandare un comando e mostrare feedback
def play(cmd: str, label: str):
    Bridge.call(cmd)
    st.success(f"▶️ Partita: {label}")

def stop():
    Bridge.call("stop")
    st.info("⏹️ Stop!")

col1, col2 = st.columns(2)

with col1:
    if st.button("Pirati dei Caraibi"):
        play("pirati", "Pirati dei Caraibi")

    if st.button("Buon Compleanno"):
        play("happy", "Buon Compleanno")

with col2:
    if st.button("Buon Natale"):
        play("christmas", "Buon Natale")

    if st.button("Super Mario"):
        play("mario", "Super Mario")

st.divider()

# Bottone STOP (opzionale ma utilissimo per la demo)
if st.button("STOP (ferma la canzone)"):
    stop()