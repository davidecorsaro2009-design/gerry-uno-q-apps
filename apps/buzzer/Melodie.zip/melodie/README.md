# Melodie

### Description

App Arduino UNO Q con Web UI (Streamlit) per scegliere e riprodurre melodie sul buzzer.

Bottoni disponibili:
- Pirati dei Caraibi
- Buon Compleanno
- Buon Natale
- Super Mario
- STOP (ferma la canzone)

Seguitemi su Youtube : Gerry&Tech

Crediti Melodie : @ArduinoFacile



